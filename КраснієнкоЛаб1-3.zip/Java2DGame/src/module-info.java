/**
 * 
 */
/**
 * 
 */
module Java2DGame {
	requires java.desktop;
}